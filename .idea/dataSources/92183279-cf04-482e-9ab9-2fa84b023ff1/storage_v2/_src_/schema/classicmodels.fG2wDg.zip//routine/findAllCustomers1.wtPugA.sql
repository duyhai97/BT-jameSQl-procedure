create
    definer = root@localhost procedure findAllCustomers1(IN customerNumber1 int)
begin
    select * from customers
        where customerNumber = customerNumber1;
end;

