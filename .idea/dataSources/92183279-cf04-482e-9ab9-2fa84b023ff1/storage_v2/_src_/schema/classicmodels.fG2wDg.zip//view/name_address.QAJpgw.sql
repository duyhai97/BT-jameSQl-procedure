create definer = root@localhost view name_address as
select `classicmodels`.`customers`.`customerName` AS `customerName`,
       `classicmodels`.`customers`.`phone`        AS `phone`,
       `classicmodels`.`customers`.`addressLine1` AS `addressLine1`
from `classicmodels`.`customers`
where (`classicmodels`.`customers`.`customerNumber` < 200);

