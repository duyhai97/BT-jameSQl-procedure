create
    definer = root@localhost procedure addProduct(IN Code int, IN name_p varchar(20), IN price int, IN amount int,
                                                  IN desr varchar(100), IN statuss tinyint)
begin
    insert product(productCode, productName, productPrice, productAmount, productDescription, productStatus) VALUES
    (Code,name_p,price,amount,desr,statuss);
end;

