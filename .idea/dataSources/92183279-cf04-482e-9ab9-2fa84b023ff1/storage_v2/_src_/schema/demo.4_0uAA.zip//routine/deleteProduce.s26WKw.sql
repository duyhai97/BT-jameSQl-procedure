create
    definer = root@localhost procedure deleteProduce(IN iddd int)
begin
    delete from demo.product where id = iddd;
end;

