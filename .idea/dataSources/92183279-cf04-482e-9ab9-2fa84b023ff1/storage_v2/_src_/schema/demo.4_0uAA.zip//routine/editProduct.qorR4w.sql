create
    definer = root@localhost procedure editProduct(IN idd int, IN Code int, IN name_p varchar(20), IN price int,
                                                   IN amount int, IN desr varchar(100), IN statuss tinyint)
begin
    update demo.product set productCode = Code, productName = name_p, productPrice = price, productAmount = amount,
                            productDescription = desr, productStatus = statuss
    where id = idd;
end;

