create
    definer = root@localhost procedure getAll()
begin
    select  * from product;
end;

